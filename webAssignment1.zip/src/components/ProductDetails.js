import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useCart } from "../context/CartContext";
import { products } from "../Constant/ProductArr";
import { Button } from "react-bootstrap";

function ProductDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  const product = products.find((p) => p.id === parseInt(id));

  if (!product) {
    return <div>Product not found</div>;
  }

  const totalPrice = product.price * quantity;

  const handleAddToCart = () => {
    debugger;
    // addToCart({ id: product.id, name: product.name, quantity });
    // addToCart({ ...product, quantity, totalPrice: product.price * quantity });
    addToCart({ ...product, quantity, totalPrice });
    console.log(`Added to Cart: ${product.name} - Quantity: ${quantity}`);

    // Redirect to the shopping cart page
    navigate("/cart");
  };

  return (
    <div>
      <h2>{product.name}</h2>
      <p>{product.description}</p>
      <p>Price: ${product.price}</p>
      <p>
        Quantity:
        <input
          type="number"
          value={quantity}
          onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
        />
      </p>
      <Button onClick={handleAddToCart}>Add to Cart</Button>
    </div>
  );
}

export default ProductDetails;
