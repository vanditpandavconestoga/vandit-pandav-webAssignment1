// This array use for the product Details
export const products = [
  {
    id: 1,
    name: "Men T-shirt",
    description: "Born to shop",
    price: 10,
    image: "images/image1.jpg",
  },
  {
    id: 2,
    name: "Men Half sleave t-shirt",
    description: "Don't Smoke in your Whole life",
    price: 12,
    image: "images/image2.jpg",
  },
  {
    id: 3,
    name: "Men T-shirt",
    description: "You Make my heart go boom",
    price: 15,
    image: "images/image3.jpg",
  },
  {
    id: 4,
    name: "Girl T-shirt",
    description: "Rich and Famous",
    price: 11,
    image: "images/image4.jpg",
  },
  {
    id: 5,
    name: "Men Full sleve T-shirt",
    description: "Gasoline",
    price: 12,
    image: "images/image5.jpg",
  },
];
